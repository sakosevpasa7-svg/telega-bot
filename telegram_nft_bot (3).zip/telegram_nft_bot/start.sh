#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "========================================"
echo "  Telegram NFT Bot — запуск"
echo "========================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "[ОШИБКА] python3 не найден. Установи Python 3.10+"
  exit 1
fi

if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
    echo "Создан файл .env из .env.example"
    echo "Открой .env и вставь BOT_TOKEN, затем запусти снова: ./start.sh"
    exit 0
  else
    echo "[ОШИБКА] Нет файла .env и .env.example"
    exit 1
  fi
fi

if grep -q 'BOT_TOKEN=1234567890' .env 2>/dev/null; then
  echo "[ОШИБКА] В .env всё ещё пример токена. Замени BOT_TOKEN на реальный."
  exit 1
fi

if [ ! -d venv ]; then
  echo "Создание виртуального окружения..."
  python3 -m venv venv
fi

# shellcheck disable=SC1091
source venv/bin/activate

echo "Установка / обновление зависимостей..."
python -m pip install --upgrade pip >/dev/null
pip install -r requirements.txt

mkdir -p data

echo
echo "Запуск бота... (Ctrl+C чтобы остановить)"
echo "========================================"
python bot.py
