@echo off
cd /d "%~dp0"
title NFT Bot

python --version
if errorlevel 1 (
    echo Python not found. Install from https://www.python.org/downloads/
    echo Check "Add python.exe to PATH" during install.
    pause
    exit /b 1
)

if not exist .env (
    copy .env.example .env
    echo Created .env - put your BOT_TOKEN there
    notepad .env
    pause
    exit /b 0
)

if not exist venv\Scripts\python.exe (
    python -m venv venv
)

call venv\Scripts\activate.bat
pip install -r requirements.txt
if not exist data mkdir data
python bot.py
pause
