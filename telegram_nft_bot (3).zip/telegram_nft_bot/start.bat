@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Telegram NFT Bot

echo ========================================
echo   Telegram NFT Bot - zapusk
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [OSHIBKA] Python ne nayden.
    echo Ustanovi Python 3.10+ s python.org
    echo i otmet "Add python.exe to PATH".
    echo.
    pause
    exit /b 1
)

if not exist ".env" (
    if exist ".env.example" (
        copy /Y ".env.example" ".env" >nul
        echo Sozdan fayl .env
        echo Otkroy .env i vstav BOT_TOKEN, potom zapusti start.bat snova.
        echo.
        notepad ".env"
        pause
        exit /b 0
    )
    echo [OSHIBKA] Net fayla .env
    pause
    exit /b 1
)

findstr /B /C:"BOT_TOKEN=1234567890" ".env" >nul 2>&1
if not errorlevel 1 (
    echo [OSHIBKA] V .env eshche primer tokena.
    echo Zameni BOT_TOKEN na realnyy.
    notepad ".env"
    pause
    exit /b 1
)

if not exist "venv\Scripts\python.exe" (
    echo Sozdanie virtualnogo okruzheniya...
    python -m venv venv
    if errorlevel 1 (
        echo [OSHIBKA] Ne udalos sozdat venv
        pause
        exit /b 1
    )
)

call "venv\Scripts\activate.bat"

echo Ustanovka zavisimostey...
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
    echo [OSHIBKA] Ne udalos ustanovit zavisimosti
    pause
    exit /b 1
)

if not exist "data" mkdir data

echo.
echo Zapusk bota... Ctrl+C chtoby ostanovit
echo ========================================
python bot.py

echo.
echo Bot ostanovlen.
pause
